class Secrets {
  static const String imgurAuthToken = 'Bearer 3c63568977bc47a4fb662f88b52e2ee401a524d2';
  static String OpenCageapiKey = 'ca01bd1ef94341cdbbe882782af58bad';

}
